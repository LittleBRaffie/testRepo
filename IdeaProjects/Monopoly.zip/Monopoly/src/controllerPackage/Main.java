package controllerPackage;

import java.util.Random;
import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);
    static Random random = new Random();
    static final int AANTAL_DOBBELSTENEN = 2;
    static final int MAX_AANTAL_SPELERS = 7;
    static char[] speelSymbolen = {'!','@','#','$','%','&','*'};

    public static void main(String[] args) {
        // Doel: Monopoly spelen met elkaar of tegen de PC. Speler kiest in begin hoeveel spelers er zijn (bij 1 automatisch
        // tegen de PC). Elke speler heeft eigen symbool (keuze). Verder gelden de normale monopoly regels (huizen, hotels,
        // geld, dobbelen, kanskaarten) TODO: spelregels opzoeken
        // Wanneer iemand heeft gewonnen, stopt het spel TODO: wanneer wint iemand? geldbedrag, huizen?

        // Input
        // welkom + uitleg
        System.out.println("\nWelkom bij Monopoly. It's time to get ritch!z\n");
        // speelbord = 40 velden
        String[] speelbord = new String[40];
        // spelers
        int aantalSpelers;
        // final values
        // kaarten
        int kanskaarten = 52; // klopt dit? beter String[]?
        // dobbelworp
        int[] dobbelworp = new int[AANTAL_DOBBELSTENEN];
        int totaalDobbelworp;

        // Verwerking
        // hoeveel spelers
        aantalSpelers = spelerInputInt("Met hoeveel spelers zijn jullie (maximaal 7)? Voer een getal in (1 - 7) " +
                "en druk op 'Enter.");
        // tekenen bord

        // dobbelworp
        dobbelworp = gooi2Dobbelstenen();
        totaalDobbelworp = berekenEnPrintTotaalDobbelworp(dobbelworp);

        // Output
    }

//    public static int inputSpelerInt (){
//        int inputInt;
//        inputInt = scanner.nextInt();
//        return inputInt;
//    }

    public static char[] spelerSymbolen(int aantalSpelers){
        // Doel: overzicht van de speelsymbolen die spelers kunnen gebruiken en waarvan elke speler er eentje kan kiezen

        // Input
        // aanmaken 7 speelsymbolen via unicode (staat in klasse) TODO Robin vragen hoe dit gaat
        // aanmaken x speelsymbolen die daadwerkelijk gebruikt worden
        char[] symbolenWaarmeeGespeeldWordt= new char[aantalSpelers];
        // weergave van spelersymbolen
        for (int i = 0; i < MAX_AANTAL_SPELERS; i++) {
            System.out.println((i+1)" = "+speelSymbolen[i]);
        }
        // variabele spelerkeuze
        int keuze = 0;

        // Verwerking
        // vragen om keuze speler x + deze opslaan
        System.out.println("Kies één van bovengenoemde symbolen door het cijfer in te toetsen en druk op 'Enter'.");
        keuze = scanner.nextInt();
        switch (keuze){ //TODO tot hier
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            default:
                break;
        }

        // Output
        // return
        return symbolenWaarmeeGespeeldWordt;
    }

    public static int genereerRandomNr() {
        // Doel: genereer random nr 1-6

        // Input

        // Verwerking

        // Output
        return random.nextInt(6)+1;
    }

    public static int[] gooi2Dobbelstenen(){
        // Doel: genereer 2 random nr 1-6

        // Input
        int[] worp = new int[AANTAL_DOBBELSTENEN];

        // Verwerking
        for (int i = 0; i < AANTAL_DOBBELSTENEN; i++) {
            worp[i] = genereerRandomNr();
            System.out.println("Worp "+(i+1)+": "+worp[i]);
        }

        // Output
        return worp;
    }

    public static int berekenEnPrintTotaalDobbelworp(int[] worp){
        // Doel: bereken totaalwaarde van 2 gegooide dobbelstenen

        // Input
        int totaal = 0;

        // Verwerking
        for (int i = 0; i < worp.length; i++) {
            totaal = totaal + worp[i];
        }

        // output
        System.out.println(totaal);
        return totaal;
    }

    public static int spelerInputInt(String vraag) {
        System.out.println(vraag);
        return scanner.nextInt();
    }

    public static void demo() {
        // Doel:

        // Input

        // Verwerking

        // Output

    }

}
